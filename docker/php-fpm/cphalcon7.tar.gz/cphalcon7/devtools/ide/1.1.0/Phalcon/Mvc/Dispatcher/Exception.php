<?php 

namespace Phalcon\Mvc\Dispatcher {

	/**
	 * Phalcon\Mvc\Dispatcher\Exception
	 *
	 * Exceptions thrown in Phalcon\Mvc\Dispatcher will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
