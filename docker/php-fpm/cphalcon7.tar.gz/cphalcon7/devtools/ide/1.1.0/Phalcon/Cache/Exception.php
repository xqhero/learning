<?php 

namespace Phalcon\Cache {

	/**
	 * Phalcon\Cache\Exception
	 *
	 * Exceptions thrown in Phalcon\Cache will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
