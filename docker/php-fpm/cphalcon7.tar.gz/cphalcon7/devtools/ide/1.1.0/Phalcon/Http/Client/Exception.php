<?php 

namespace Phalcon\Http\Client {

	/**
	 * Phalcon\Http\Client\Exception
	 *
	 * Exceptions thrown in Phalcon\Http\Client will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
