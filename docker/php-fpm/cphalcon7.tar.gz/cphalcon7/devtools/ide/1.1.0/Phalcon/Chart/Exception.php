<?php 

namespace Phalcon\Chart {

	/**
	 * Phalcon\Chart\Exception
	 *
	 * Exceptions thrown in Phalcon\Chart will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
