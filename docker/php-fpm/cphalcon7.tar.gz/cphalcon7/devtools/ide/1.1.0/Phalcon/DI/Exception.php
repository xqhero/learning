<?php 

namespace Phalcon\Di {

	/**
	 * Phalcon\Di\Exception
	 *
	 * Exceptions thrown in Phalcon\Di will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
