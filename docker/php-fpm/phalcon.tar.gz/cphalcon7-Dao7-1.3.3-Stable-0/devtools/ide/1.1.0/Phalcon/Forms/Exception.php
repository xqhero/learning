<?php 

namespace Phalcon\Forms {

	/**
	 * Phalcon\Forms\Exception
	 *
	 * Exceptions thrown in Phalcon\Forms will use this class
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
