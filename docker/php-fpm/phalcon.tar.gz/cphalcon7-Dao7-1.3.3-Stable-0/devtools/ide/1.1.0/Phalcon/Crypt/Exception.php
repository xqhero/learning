<?php 

namespace Phalcon\Crypt {

	/**
	 * Phalcon\Crypt\Exception
	 *
	 * Exceptions thrown in Phalcon\Crypt use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
