<?php 

namespace Phalcon\Mvc\Application {

	/**
	 * Phalcon\Mvc\Application\Exception
	 *
	 * Exceptions thrown in Phalcon\Mvc\Application class will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
