<?php 

namespace Phalcon\Security {

	/**
	 * Phalcon\Security\Exception
	 *
	 * Exceptions thrown in Phalcon\Security will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
