<?php 

namespace Phalcon {

	class Kernel {

		public static function preComputeHashKey($arrKey){ }


		public static function preComputeHashKey32($arrKey){ }


		public static function preComputeHashKey64($arrKey){ }

	}
}
