<?php 

namespace Phalcon\Mvc\Router {

	/**
	 * Phalcon\Mvc\Router\Exception
	 *
	 * Exceptions thrown in Phalcon\Mvc\Router will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
