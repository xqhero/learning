<?php 

namespace Phalcon {

	/**
	 * Phalcon\ContinueException
	 *
	 * All framework exceptions should use or extend this exception
	 */
	
	class ContinueException extends \Exception implements \Throwable {
	}
}
