<?php 

namespace Phalcon\Binary {

	/**
	 * Phalcon\Binary\Exception
	 *
	 * Exceptions thrown in Phalcon\Binary will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
