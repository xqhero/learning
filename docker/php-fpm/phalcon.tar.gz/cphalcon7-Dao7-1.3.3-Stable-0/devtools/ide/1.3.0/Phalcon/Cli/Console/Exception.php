<?php 

namespace Phalcon\Cli\Console {

	/**
	 * Phalcon\Cli\Console\Exception
	 *
	 * Exceptions thrown in Phalcon\Cli\Console will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
